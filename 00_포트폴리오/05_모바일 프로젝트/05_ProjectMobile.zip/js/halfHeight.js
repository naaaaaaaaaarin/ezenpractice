// 브라우저 너비,높이 변수 할당
let bw = $(window).width();
let bh = $(window).height();
$('#wrap').css({height:bh});
// 브라우저 높이의 반을 변수 할당
var halfHeight = bh/2;
// 적용
$('.youtube').css({'margin-top':halfHeight});
