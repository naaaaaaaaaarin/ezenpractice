// 1. 이벤트 호출
$('#myBtn').on('click',myFunction);
// 2. 이벤트 리스너(핸들러)
function myFunction(){
    var dots = $('#dots');
    var moreButton = $('#more');
    var btnText = $('#myBtn');
    var result = $('#dots').css('display');
    // console.log(dots);
    // 3. 기능 코딩(more 내용 나오게 하기)
    if(result=='none'){
        dots.css({display:'inline'});
        moreButton.css({display:'none'});
        btnText.text('+ MORE');
    }else{ // 초기 로딩상태 시작(...이 있으면 ??? 해라)
        dots.css({display:'none'});
        moreButton.css({display:'inline'});
        btnText.text('- CLOSE');
    }
}

